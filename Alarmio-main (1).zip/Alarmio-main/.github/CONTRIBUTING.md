## Branches

The `develop` branch should be used used for all current changes and pull requests - `master` only contains the last release. The only exception to this is when changing the README or related files (such as this one) that should be immediately visible to users.

This project uses [GitHub Actions](https://github.com/features/actions) to build and deploy anything pushed to the `master` branch.

