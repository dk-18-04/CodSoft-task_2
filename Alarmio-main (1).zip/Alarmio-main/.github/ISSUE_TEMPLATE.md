<!--
Please verify that there are no duplicate issues before creating one, and check that you are using the latest version of the app.
For crash reports and other bugs and errors, please use the template below to add your device info so that I can find the cause more easily.
For the angels that are contributing / building the app yourself, please read CONTRIBUTING.md (in /.github) before reporting any issues as there are certain instructions you must follow to compile a working version of the app.
-->

## Device Info

- Brand: `Samsunokiapplackberriaomissentialg`
- Model name: `John Doe`
- Android version: `Stock, hopefully.`

## Steps to Reproduce

- download the app
- hop on your left foot three times
- turn 90 degrees counterclockwise
- head, shoulders knees and toes knees and toes knees and toes knees and toes knees and toes knees and toes knees and toes knees and toes knees and toes
