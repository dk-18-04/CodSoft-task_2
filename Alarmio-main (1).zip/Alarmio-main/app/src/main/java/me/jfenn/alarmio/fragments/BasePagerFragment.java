package me.jfenn.alarmio.fragments;

import android.content.Context;

public abstract class BasePagerFragment extends BaseFragment {

    public abstract String getTitle(Context context);

}
