package me.jfenn.alarmio.interfaces;

import me.jfenn.alarmio.data.SoundData;

public interface SoundChooserListener {
    void onSoundChosen(SoundData sound);
}
